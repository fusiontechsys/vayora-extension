# Sentinel by Vayora

Android app (Kotlin + Jetpack Compose). Build the APK with GitHub Actions:

1. Create a GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab -> **Build Sentinel APK** -> **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download the **Sentinel-APK** artifact (contains `Sentinel.apk`).

Signing: the workflow creates `keystore/vayora.jks` only if the file is missing. To keep the same
signature across builds (so updates install over the old app), commit that keystore once.

Google Drive sign-in needs your OAuth client registered in Google Cloud for the package
`com.vayora.extension` and the SHA-1 of your signing key.
