package com.vayora.extension.ui

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

@Composable
fun RecoverySettingsScreen(vm: RecoveryViewModel, onBack: () -> Unit) {
    val hasPhrase by vm.hasPhrase.collectAsStateWithLifecycle()
    val email by vm.driveEmail.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var current by remember { mutableStateOf("") }
    var newPhrase by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    SentinelPage(
        title = "Recovery Settings",
        subtitle = "Your way back in if you forget the passcode.",
        onBack = onBack
    ) {
        Panel(
            "How recovery works",
            "If you forget your passcode, you verify your registered Google account and " +
                "then enter your recovery phrase. Both are required. Without a recovery " +
                "phrase, a forgotten passcode can only be fixed by reinstalling the app."
        )
        GroupCard {
            StatusRow(
                "Google account",
                if (email == null) "Not connected" else "Connected",
                if (email == null) Tone.WARN else Tone.GOOD,
                email ?: "Connect it in Google Account first."
            )
            RowDivider()
            StatusRow(
                "Recovery phrase",
                if (hasPhrase) "Set" else "Not set",
                if (hasPhrase) Tone.GOOD else Tone.WARN,
                if (hasPhrase) "Stored only as a salted hash." else "Create one below."
            )
        }

        SectionLabel(if (hasPhrase) "Change phrase" else "Create phrase")
        if (hasPhrase) {
            SentinelTextField(
                value = current,
                onValueChange = { current = it },
                label = "Current recovery phrase"
            )
        }
        SentinelTextField(
            value = newPhrase,
            onValueChange = { newPhrase = it },
            label = if (hasPhrase) "New recovery phrase" else "Recovery phrase"
        )
        SentinelTextField(
            value = confirm,
            onValueChange = { confirm = it },
            label = "Repeat recovery phrase"
        )
        error?.let { Panel("Problem", it, true) }
        if (saved) {
            Panel("Saved", "Your recovery phrase is saved. Keep a written copy somewhere safe.")
        }
        PrimaryButton(
            text = if (busy) "Saving..." else if (hasPhrase) "Change phrase" else "Save phrase",
            onClick = {
                scope.launch {
                    busy = true
                    saved = false
                    error = vm.changePhrase(current, newPhrase, confirm)
                    if (error == null) {
                        saved = true
                        current = ""
                        newPhrase = ""
                        confirm = ""
                    }
                    busy = false
                }
            },
            enabled = !busy && newPhrase.isNotBlank()
        )
    }
}
