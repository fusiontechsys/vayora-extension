package com.vayora.extension.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.vayora.extension.R
import com.vayora.extension.ui.theme.Crimson
import com.vayora.extension.ui.theme.CrimsonBright
import com.vayora.extension.ui.theme.Danger
import com.vayora.extension.ui.theme.GraphiteHigh
import com.vayora.extension.ui.theme.GraphiteHighest
import com.vayora.extension.ui.theme.Hairline
import com.vayora.extension.ui.theme.Success
import com.vayora.extension.ui.theme.TextPrimary
import com.vayora.extension.ui.theme.TextSecondary
import com.vayora.extension.ui.theme.TextTertiary
import com.vayora.extension.ui.theme.Warning
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Tone { GOOD, WARN, BAD, NONE }

fun toneColor(tone: Tone): Color = when (tone) {
    Tone.GOOD -> Success
    Tone.WARN -> Warning
    Tone.BAD -> Danger
    Tone.NONE -> TextSecondary
}

fun formatTimestamp(ms: Long): String =
    SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ms))

// ---------------------------------------------------------------- brand

@Composable
fun BrandLockup(width: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.sentinel_logo),
        contentDescription = "Sentinel by Vayora",
        contentScale = ContentScale.FillWidth,
        modifier = modifier.width(width).aspectRatio(1080f / 269f)
    )
}

@Composable
fun BrandMark(height: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.sentinel_mark),
        contentDescription = "Sentinel",
        contentScale = ContentScale.FillHeight,
        modifier = modifier.height(height).aspectRatio(384f / 442f)
    )
}

// ---------------------------------------------------------------- layout

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, Hairline, CircleShape)
                .clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = TextPrimary,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(Modifier.height(24.dp))
        Text(title, style = MaterialTheme.typography.headlineMedium)
        if (subtitle != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SentinelPage(
    title: String,
    onBack: () -> Unit,
    subtitle: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, end = 24.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        ScreenHeader(title, onBack, subtitle)
        content()
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        color = TextTertiary,
        modifier = modifier.padding(start = 4.dp, top = 8.dp)
    )
}

@Composable
fun SurfaceCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    padding: PaddingValues = PaddingValues(20.dp),
    borderColor: Color = Hairline,
    background: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    val base = modifier
        .fillMaxWidth()
        .clip(shape)
        .background(background)
        .border(1.dp, borderColor, shape)
    val tappable = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(modifier = tappable.padding(padding), content = content)
}

@Composable
fun GroupCard(content: @Composable ColumnScope.() -> Unit) {
    SurfaceCard(padding = PaddingValues(0.dp), content = content)
}

@Composable
fun RowDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .height(1.dp)
            .background(Hairline)
    )
}

/** Simple titled text block. [warn] tints it amber for problems and attention items. */
@Composable
fun Panel(title: String, body: String, warn: Boolean = false) {
    SurfaceCard(
        borderColor = if (warn) Warning.copy(alpha = 0.35f) else Hairline
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            color = if (warn) Warning else TextPrimary
        )
        Spacer(Modifier.height(8.dp))
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun IconBadge(icon: ImageVector, tint: Color = CrimsonBright, size: Dp = 44.dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(14.dp))
            .background(tint.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun StatusPill(text: String, tone: Tone) {
    val color = toneColor(tone)
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.14f))
            .padding(horizontal = 12.dp, vertical = 5.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = color)
    }
}

// ---------------------------------------------------------------- rows

@Composable
fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f).padding(end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Crimson,
                checkedBorderColor = Crimson,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = GraphiteHigh,
                uncheckedBorderColor = GraphiteHighest
            )
        )
    }
}

@Composable
fun StatusRow(name: String, status: String, tone: Tone, note: String) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                name,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f).padding(end = 12.dp)
            )
            StatusPill(status, tone)
        }
        Text(note, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
    }
}

@Composable
fun KeyValueRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            modifier = Modifier.weight(1f).padding(end = 12.dp)
        )
        Text(value, style = MaterialTheme.typography.titleSmall)
    }
}

// ---------------------------------------------------------------- inputs

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Crimson,
            contentColor = Color.White,
            disabledContainerColor = GraphiteHigh,
            disabledContentColor = TextTertiary
        ),
        modifier = modifier.fillMaxWidth().heightIn(min = 56.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, GraphiteHighest),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = TextPrimary,
            disabledContentColor = TextTertiary
        ),
        modifier = modifier.fillMaxWidth().heightIn(min = 56.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun SentinelTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    secret: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        visualTransformation = if (secret) PasswordVisualTransformation()
        else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (secret) KeyboardType.Password else KeyboardType.Text
        ),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
            cursorColor = Crimson,
            focusedBorderColor = Crimson,
            unfocusedBorderColor = GraphiteHighest,
            focusedLabelColor = CrimsonBright,
            unfocusedLabelColor = TextSecondary
        ),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun SentinelChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelLarge) },
        shape = RoundedCornerShape(50),
        colors = FilterChipDefaults.filterChipColors(
            containerColor = Color.Transparent,
            labelColor = TextSecondary,
            selectedContainerColor = Crimson.copy(alpha = 0.18f),
            selectedLabelColor = CrimsonBright
        )
    )
}
