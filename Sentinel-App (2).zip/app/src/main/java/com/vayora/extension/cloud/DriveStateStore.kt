package com.vayora.extension.cloud

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class DriveState(
    val email: String? = null,
    val folderId: String? = null,
    val lastSync: Long? = null,
    val lastError: String? = null,
    val syncing: Boolean = false
)

/** Remembers which Google account is registered and how the last sync went. */
class DriveStateStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("sentinel_drive", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(
        DriveState(
            email = prefs.getString(KEY_EMAIL, null),
            folderId = prefs.getString(KEY_FOLDER, null),
            lastSync = if (prefs.contains(KEY_SYNC)) prefs.getLong(KEY_SYNC, 0L) else null,
            lastError = prefs.getString(KEY_ERROR, null)
        )
    )
    val state: StateFlow<DriveState> = _state.asStateFlow()

    fun register(email: String) {
        prefs.edit().putString(KEY_EMAIL, email).remove(KEY_ERROR).apply()
        _state.value = _state.value.copy(email = email, lastError = null)
    }

    fun setFolder(id: String) {
        prefs.edit().putString(KEY_FOLDER, id).apply()
        _state.value = _state.value.copy(folderId = id)
    }

    fun setSyncing(value: Boolean) {
        _state.value = _state.value.copy(syncing = value)
    }

    fun setError(text: String) {
        prefs.edit().putString(KEY_ERROR, text).apply()
        _state.value = _state.value.copy(lastError = text)
    }

    fun clearError() {
        prefs.edit().remove(KEY_ERROR).apply()
        _state.value = _state.value.copy(lastError = null)
    }

    fun markSynced(time: Long) {
        prefs.edit().putLong(KEY_SYNC, time).remove(KEY_ERROR).apply()
        _state.value = _state.value.copy(lastSync = time, lastError = null)
    }

    /** Forgets the registered account. Files already in Drive are not touched. */
    fun disconnect() {
        prefs.edit().clear().apply()
        _state.value = DriveState()
    }

    private companion object {
        const val KEY_EMAIL = "email"
        const val KEY_FOLDER = "folder"
        const val KEY_SYNC = "last_sync"
        const val KEY_ERROR = "last_error"
    }
}
