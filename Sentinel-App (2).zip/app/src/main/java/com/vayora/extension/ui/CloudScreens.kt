package com.vayora.extension.ui

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.ApiException
import com.vayora.extension.VayoraApp
import com.vayora.extension.cloud.DriveClient
import com.vayora.extension.cloud.DriveState
import com.vayora.extension.cloud.GoogleAuth
import com.vayora.extension.cloud.SyncScheduler
import com.vayora.extension.ui.theme.TextSecondary
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class CloudUi(val busy: Boolean = false, val message: String? = null)

class CloudViewModel(private val app: VayoraApp) : ViewModel() {

    private val store = app.driveState

    val drive: StateFlow<DriveState> = store.state

    val pending: StateFlow<Int> = app.repository.pendingCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    private val _ui = MutableStateFlow(CloudUi())
    val ui: StateFlow<CloudUi> = _ui.asStateFlow()

    fun clearMessage() {
        _ui.update { it.copy(message = null) }
    }

    fun report(text: String) {
        _ui.value = CloudUi(busy = false, message = text)
    }

    fun onGoogleToken(token: String) {
        viewModelScope.launch {
            _ui.value = CloudUi(busy = true)
            try {
                val email = withContext(Dispatchers.IO) { DriveClient(token).aboutEmail() }
                val registered = store.state.value.email
                if (registered != null && !registered.equals(email, ignoreCase = true)) {
                    _ui.value = CloudUi(
                        message = "That is not the registered account ($registered). " +
                            "Disconnect first to use a different account."
                    )
                } else {
                    store.register(email)
                    store.clearError()
                    SyncScheduler.syncSoon(app)
                    _ui.value = CloudUi(message = "Connected as $email.")
                }
            } catch (e: IOException) {
                _ui.value = CloudUi(message = "Could not reach Google. Check your connection.")
            } catch (e: Exception) {
                _ui.value = CloudUi(message = "Could not verify the Google account.")
            }
        }
    }

    fun syncNow() {
        if (store.state.value.email == null) {
            _ui.value = CloudUi(message = "Connect a Google account first.")
            return
        }
        store.clearError()
        SyncScheduler.syncSoon(app)
        _ui.value = CloudUi(message = "Sync requested. It runs as soon as you are online.")
    }

    fun disconnect() {
        SyncScheduler.cancelAll(app)
        store.disconnect()
        _ui.value = CloudUi()
    }

    companion object {
        fun factory(app: VayoraApp): ViewModelProvider.Factory =
            viewModelFactory {
                initializer { CloudViewModel(app) }
            }
    }
}

private fun driveTone(drive: DriveState): Pair<String, Tone> = when {
    drive.email == null -> "Not connected" to Tone.WARN
    drive.lastError != null -> "Needs attention" to Tone.WARN
    drive.syncing -> "Syncing" to Tone.NONE
    else -> "Connected" to Tone.GOOD
}

@Composable
fun GoogleAccountScreen(vm: CloudViewModel, onBack: () -> Unit) {
    val drive by vm.drive.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var confirmDisconnect by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            try {
                val granted = Identity.getAuthorizationClient(context)
                    .getAuthorizationResultFromIntent(data)
                val token = granted.accessToken
                if (token != null) {
                    vm.onGoogleToken(token)
                } else {
                    vm.report("Google did not return an access token.")
                }
            } catch (e: ApiException) {
                vm.report("Google sign-in failed (code ${e.statusCode}).")
            }
        } else {
            vm.report("Google sign-in was cancelled.")
        }
    }

    val connect: () -> Unit = {
        Identity.getAuthorizationClient(context)
            .authorize(GoogleAuth.request(drive.email))
            .addOnSuccessListener { result ->
                if (result.hasResolution()) {
                    val pending = result.pendingIntent
                    if (pending != null) {
                        launcher.launch(IntentSenderRequest.Builder(pending.intentSender).build())
                    } else {
                        vm.report("Google could not open the sign-in screen.")
                    }
                } else {
                    val token = result.accessToken
                    if (token != null) {
                        vm.onGoogleToken(token)
                    } else {
                        vm.report("Google did not return an access token.")
                    }
                }
            }
            .addOnFailureListener { error ->
                vm.report("Google sign-in failed: ${error.message}")
            }
    }

    val (statusText, statusTone) = driveTone(drive)

    SentinelPage(
        title = "Google Account",
        subtitle = "Evidence is stored only in the Drive account you register here.",
        onBack = onBack
    ) {
        GroupCard {
            Row(
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f).padding(end = 12.dp)) {
                    Text(
                        "Registered account",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Text(
                        drive.email ?: "None yet",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                StatusPill(statusText, statusTone)
            }
        }

        drive.lastError?.let { Panel("Needs attention", it, true) }
        ui.message?.let { Panel("Status", it) }

        PrimaryButton(
            text = when {
                ui.busy -> "Checking..."
                drive.email == null -> "Connect Google account"
                else -> "Reconnect"
            },
            onClick = connect,
            enabled = !ui.busy
        )
        if (drive.email != null) {
            SecondaryButton(text = "Disconnect", onClick = { confirmDisconnect = true })
        }

        Panel(
            "What Sentinel can access",
            "Sentinel asks only for access to files it creates itself (drive.file). It " +
                "cannot see anything else in your Google Drive."
        )
    }

    if (confirmDisconnect) {
        AlertDialog(
            onDismissRequest = { confirmDisconnect = false },
            title = { Text("Disconnect Google?") },
            text = {
                Text(
                    "Uploads stop and passcode recovery stops working until you connect " +
                        "again. Files already in Google Drive stay there."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDisconnect = false
                    vm.disconnect()
                }) { Text("Disconnect") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDisconnect = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun CloudEvidenceScreen(vm: CloudViewModel, onBack: () -> Unit) {
    val drive by vm.drive.collectAsStateWithLifecycle()
    val pending by vm.pending.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val (statusText, statusTone) = driveTone(drive)

    SentinelPage(
        title = "Cloud Evidence",
        subtitle = "Photos and event logs upload to your private Drive folder.",
        onBack = onBack
    ) {
        GroupCard {
            Row(
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Google Drive",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                StatusPill(statusText, statusTone)
            }
            RowDivider()
            KeyValueRow("Pending uploads", pending.toString())
            RowDivider()
            KeyValueRow(
                "Last successful sync",
                drive.lastSync?.let { formatTimestamp(it) } ?: "Never"
            )
            RowDivider()
            KeyValueRow("Account", drive.email ?: "Not connected")
        }

        drive.lastError?.let { Panel("Sync problem", it, true) }
        ui.message?.let { Panel("Status", it) }

        PrimaryButton(
            text = if (drive.syncing) "Syncing..." else "Sync now",
            onClick = { vm.syncNow() },
            enabled = drive.email != null && !drive.syncing
        )
        if (drive.email == null) {
            Panel(
                "Not connected",
                "Open Google Account and connect a Drive account so evidence can upload.",
                true
            )
        }
    }
}
