package com.vayora.extension.ui

import androidx.compose.runtime.Composable

@Composable
fun PasscodeSettingsScreen(
    onBack: () -> Unit,
    onChange: () -> Unit,
    onLockNow: () -> Unit
) {
    SentinelPage(
        title = "Passcode Settings",
        subtitle = "A six-digit passcode guards the app.",
        onBack = onBack
    ) {
        Panel(
            "Storage",
            "Your passcode is never stored. Only a salted PBKDF2-SHA256 hash is kept, " +
                "encrypted with a key held in the Android Keystore."
        )
        Panel(
            "Relock",
            "The app locks every time you leave it, including when the screen turns off " +
                "or you switch to another app."
        )
        SectionLabel("Lockout schedule")
        GroupCard {
            KeyValueRow("5 wrong attempts", "30 seconds")
            RowDivider()
            KeyValueRow("6 wrong attempts", "1 minute")
            RowDivider()
            KeyValueRow("7 wrong attempts", "5 minutes")
            RowDivider()
            KeyValueRow("8 wrong attempts", "15 minutes")
            RowDivider()
            KeyValueRow("9 wrong attempts", "1 hour")
            RowDivider()
            KeyValueRow("10 or more", "24 hours")
        }
        PrimaryButton(text = "Change passcode", onClick = onChange)
        SecondaryButton(text = "Lock now", onClick = onLockNow)
    }
}
