package com.vayora.extension.ui.theme

import androidx.compose.ui.graphics.Color

// Sentinel palette: graphite surfaces with crimson light, taken from the logo.
val Ink = Color(0xFF0D0D0F)
val Graphite = Color(0xFF16171A)
val GraphiteHigh = Color(0xFF1E2024)
val GraphiteHighest = Color(0xFF26282D)
val Hairline = Color(0xFF2B2D33)

val Crimson = Color(0xFFE01E2F)
val CrimsonBright = Color(0xFFFF4A3D)
val CrimsonDeep = Color(0xFFA50F2B)

val TextPrimary = Color(0xFFF4F4F6)
val TextSecondary = Color(0xFFA0A2AB)
val TextTertiary = Color(0xFF6F717A)

val Danger = Color(0xFFFF6B6B)
val Success = Color(0xFF3DDC97)
val Warning = Color(0xFFFFB84D)
