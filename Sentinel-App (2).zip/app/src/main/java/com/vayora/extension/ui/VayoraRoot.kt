package com.vayora.extension.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vayora.extension.ui.theme.CrimsonBright
import com.vayora.extension.ui.theme.TextSecondary
import com.vayora.extension.ui.theme.Warning

@Composable
fun SentinelRoot(
    dashboard: DashboardViewModel,
    auth: AuthViewModel,
    cloud: CloudViewModel,
    gallery: GalleryViewModel,
    monitor: MonitorViewModel,
    recovery: RecoveryViewModel
) {
    val authUi by auth.ui.collectAsStateWithLifecycle()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(Modifier.systemBarsPadding()) {
            when (authUi.stage) {
                Stage.UNLOCKED -> DashboardHost(dashboard, auth, cloud, gallery, monitor, recovery)
                Stage.RECOVERY -> RecoveryScreen(recovery, auth)
                else -> LockScreen(authUi, auth)
            }
        }
    }
}

@Composable
private fun DashboardHost(
    dashboard: DashboardViewModel,
    auth: AuthViewModel,
    cloud: CloudViewModel,
    gallery: GalleryViewModel,
    monitor: MonitorViewModel,
    recovery: RecoveryViewModel
) {
    val state by dashboard.state.collectAsStateWithLifecycle()
    var selected by rememberSaveable { mutableStateOf<String?>(null) }

    BackHandler(enabled = selected != null) { selected = null }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Crossfade(targetState = selected, label = "screen") { target ->
                val section = Sections.firstOrNull { it.title == target }
                val back = { selected = null }
                when {
                    section == null -> Column(Modifier.fillMaxSize()) {
                        if (!state.recoveryReady) {
                            RecoveryBanner { selected = "Recovery Settings" }
                        }
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            OverviewScreen(
                                state = state,
                                onOpen = { selected = it.title },
                                onLock = { auth.lock() }
                            )
                        }
                    }
                    section.title == "Passcode Settings" -> PasscodeSettingsScreen(
                        onBack = back,
                        onChange = { auth.startChange() },
                        onLockNow = { auth.lock() }
                    )
                    section.title == "Google Account" -> GoogleAccountScreen(cloud, back)
                    section.title == "Cloud Evidence" -> CloudEvidenceScreen(cloud, back)
                    section.title == "Photo Gallery" -> PhotoGalleryScreen(gallery, back)
                    section.title == "Device Security" -> DeviceSecurityScreen(monitor, back)
                    section.title == "Security Activity" -> SecurityActivityScreen(monitor, back)
                    section.title == "Recovery Settings" -> RecoverySettingsScreen(recovery, back)
                    section.title == "Application Settings" -> AppSettingsScreen(
                        onBack = back,
                        onSecureLogout = {
                            cloud.disconnect()
                            gallery.clear()
                            auth.lock()
                        }
                    )
                    else -> Box(Modifier.fillMaxSize())
                }
            }
        }
    }
}

@Composable
private fun RecoveryBanner(onSetUp: () -> Unit) {
    SurfaceCard(
        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 12.dp),
        padding = androidx.compose.foundation.layout.PaddingValues(
            start = 20.dp, end = 8.dp, top = 12.dp, bottom = 12.dp
        ),
        borderColor = Warning.copy(alpha = 0.35f)
    ) {
        androidx.compose.foundation.layout.Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(
                "Passcode recovery is not ready. A forgotten passcode cannot be reset.",
                style = MaterialTheme.typography.bodySmall,
                color = Warning,
                modifier = Modifier.weight(1f).padding(end = 8.dp)
            )
            TextButton(
                onClick = onSetUp,
                colors = ButtonDefaults.textButtonColors(contentColor = CrimsonBright)
            ) { Text("Set up") }
        }
    }
}
