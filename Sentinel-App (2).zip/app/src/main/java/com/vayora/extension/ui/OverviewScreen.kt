package com.vayora.extension.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vayora.extension.monitor.MonitorService
import com.vayora.extension.ui.theme.Crimson
import com.vayora.extension.ui.theme.Graphite
import com.vayora.extension.ui.theme.Hairline
import com.vayora.extension.ui.theme.Success
import com.vayora.extension.ui.theme.TextPrimary
import com.vayora.extension.ui.theme.TextSecondary
import com.vayora.extension.ui.theme.TextTertiary
import com.vayora.extension.ui.theme.Warning

@Composable
fun OverviewScreen(
    state: DashboardState,
    onOpen: (Section) -> Unit,
    onLock: () -> Unit
) {
    val monitoring by MonitorService.running.collectAsStateWithLifecycle()
    val groups = remember { Sections.groupBy { it.group } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 24.dp, end = 24.dp, top = 16.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item { TopBar(onLock) }
        item { StatusHero(monitoring, state) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(state.eventCount.toString(), "Events", Modifier.weight(1f))
                StatTile(state.photoCount.toString(), "Photos", Modifier.weight(1f))
                StatTile(state.pendingUploads.toString(), "Pending", Modifier.weight(1f))
            }
        }
        item { CloudCard(state) }
        groups.forEach { (name, list) ->
            item(key = name) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionLabel(name)
                    GroupCard {
                        list.forEachIndexed { index, section ->
                            if (index > 0) RowDivider()
                            MenuRow(section, onOpen)
                        }
                    }
                }
            }
        }
        item {
            Text(
                "Sentinel by Vayora",
                style = MaterialTheme.typography.bodySmall,
                color = TextTertiary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun TopBar(onLock: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f)) { BrandLockup(width = 200.dp) }
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, Hairline, CircleShape)
                .clickable(onClick = onLock),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Filled.Lock,
                contentDescription = "Lock now",
                tint = TextPrimary,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
private fun StatusHero(monitoring: Boolean, state: DashboardState) {
    val shape = RoundedCornerShape(28.dp)
    val accent = if (monitoring) Success else Warning
    val brush = if (monitoring) {
        Brush.verticalGradient(listOf(Crimson.copy(alpha = 0.24f), Graphite))
    } else {
        Brush.verticalGradient(listOf(Graphite, Graphite))
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(brush)
            .border(1.dp, if (monitoring) Crimson.copy(alpha = 0.35f) else Hairline, shape)
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(accent))
            Text(
                if (monitoring) "PROTECTION ACTIVE" else "PROTECTION OFF",
                style = MaterialTheme.typography.labelMedium,
                color = accent,
                modifier = Modifier.padding(start = 10.dp)
            )
        }
        Text(
            if (monitoring) "Sentinel is watching" else "Monitoring is turned off",
            style = MaterialTheme.typography.headlineSmall
        )
        val last = state.lastEvent
        Text(
            if (last == null) {
                "No security events recorded yet."
            } else {
                "Last event: ${last.type}\n${formatTimestamp(last.timestamp)}"
            },
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )
        if (last != null && last.isNight) {
            Text(
                "Night activity",
                style = MaterialTheme.typography.labelMedium,
                color = Warning
            )
        }
    }
}

@Composable
private fun StatTile(value: String, label: String, modifier: Modifier = Modifier) {
    SurfaceCard(modifier = modifier, padding = PaddingValues(18.dp)) {
        Text(value, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
    }
}

@Composable
private fun CloudCard(state: DashboardState) {
    val tone = when (state.driveStatus) {
        "Connected" -> Tone.GOOD
        else -> Tone.WARN
    }
    SurfaceCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Google Drive backup",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f)
            )
            StatusPill(state.driveStatus, tone)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Last sync: " + (state.lastSync?.let { formatTimestamp(it) } ?: "never"),
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )
    }
}

@Composable
private fun MenuRow(section: Section, onOpen: (Section) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpen(section) }
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBadge(section.icon)
        Column(
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(section.title, style = MaterialTheme.typography.titleMedium)
            Text(section.blurb, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = TextTertiary
        )
    }
}
