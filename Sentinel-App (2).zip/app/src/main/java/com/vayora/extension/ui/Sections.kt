package com.vayora.extension.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

data class Section(
    val title: String,
    val blurb: String,
    val group: String,
    val icon: ImageVector
)

val Sections: List<Section> = listOf(
    Section("Device Security", "Monitoring and camera evidence", "Protection", Icons.Filled.CheckCircle),
    Section("Security Activity", "Timeline of every event", "Protection", Icons.Filled.DateRange),
    Section("Photo Gallery", "Evidence photos from Drive", "Protection", Icons.Filled.AccountBox),
    Section("Cloud Evidence", "Uploads and sync status", "Cloud", Icons.Filled.Refresh),
    Section("Google Account", "Registered Drive account", "Cloud", Icons.Filled.AccountCircle),
    Section("Passcode Settings", "Six-digit passcode and lockouts", "Account", Icons.Filled.Lock),
    Section("Recovery Settings", "Google-verified recovery", "Account", Icons.Filled.Email),
    Section("Application Settings", "Privacy and secure logout", "Account", Icons.Filled.Settings)
)
