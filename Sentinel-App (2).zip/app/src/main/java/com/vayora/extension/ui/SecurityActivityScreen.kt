package com.vayora.extension.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vayora.extension.data.SecurityEvent
import com.vayora.extension.monitor.EventType
import com.vayora.extension.ui.theme.Danger
import com.vayora.extension.ui.theme.Success
import com.vayora.extension.ui.theme.TextSecondary
import com.vayora.extension.ui.theme.TextTertiary
import com.vayora.extension.ui.theme.Warning

private val Filters = listOf("All", "Failed attempts", "Unlocks", "Night")

@Composable
fun SecurityActivityScreen(vm: MonitorViewModel, onBack: () -> Unit) {
    val events by vm.events.collectAsStateWithLifecycle()
    var filter by rememberSaveable { mutableStateOf("All") }

    val visible = events.filter { event ->
        when (filter) {
            "Failed attempts" -> event.type == EventType.FAILED_AUTH
            "Unlocks" -> event.type == EventType.UNLOCK
            "Night" -> event.isNight
            else -> true
        }
    }.take(500)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ScreenHeader(
                "Security Activity",
                onBack,
                "${visible.size} events, newest first"
            )
        }
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Filters.forEach { name ->
                    SentinelChip(name, filter == name) { filter = name }
                }
            }
        }
        if (visible.isEmpty()) {
            item {
                Panel(
                    "Nothing recorded yet",
                    "Turn on monitoring in Device Security. Unlocks, failed attempts and " +
                        "restarts then appear here."
                )
            }
        }
        items(visible, key = { it.id }) { event ->
            EventCard(event)
        }
    }
}

@Composable
private fun EventCard(event: SecurityEvent) {
    val dot = when (event.type) {
        EventType.FAILED_AUTH, EventType.WRONG_PASSCODE -> Danger
        EventType.UNLOCK -> Success
        else -> TextTertiary
    }
    SurfaceCard {
        Row(verticalAlignment = Alignment.Top) {
            Box(
                Modifier
                    .padding(top = 6.dp, end = 14.dp)
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(dot)
            )
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(event.type, style = MaterialTheme.typography.titleMedium)
                Text(
                    formatTimestamp(event.timestamp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                if (event.details.isNotEmpty()) {
                    Text(event.details, style = MaterialTheme.typography.bodySmall)
                }
                if (event.deviceState.isNotEmpty()) {
                    Text(
                        event.deviceState,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextTertiary
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    if (event.isNight) StatusPill("Night", Tone.WARN)
                    StatusPill(
                        if (event.synced) "Uploaded" else "Waiting",
                        if (event.synced) Tone.GOOD else Tone.WARN
                    )
                }
            }
        }
    }
}
